@echo off
@cd %~dp0config
type introPL.txt
@cd %~dp0
echo Nacisnij dowolny klawisz aby przejsc dalej...
@pause >nul

cls
:Opc1
cls
echo CraftRunner by Jakub Pykosz. BETA 7
echo.
echo Korzystasz z dysku %~d0 .
echo.
echo Uzyj kl. W i S aby nawigowac po Menu.
echo Uzyj K aby zatwierdzic wybor.
echo. 
echo Ta opcja uruchomi gre z lokalizacji, z jakiej uruchamiasz ten program.
echo UWAGA: zapis/odczyt beda wolne.
echo Mozna uruchomic tak gre zeby ja na stale zaaktualizowac.
echo.
echo =Uruchom gre z USB=
echo Skopiuj i uruchom gre z komputera
echo Przenies gre i zapisy z powrotem na USB
echo Pomoc (FAQ)
choice /c:wsk >nul
if %errorlevel%==1 goto opc4
if %errorlevel%==2 goto opc2
if %errorlevel%==3 goto wybropc1
cls

:Opc2
cls
echo CraftRunner by Jakub Pykosz. BETA 7
echo.
echo Korzystasz z dysku %~d0 .
echo.
echo Uzyj kl. W i S aby nawigowac po Menu.
echo Uzyj K aby zatwierdzic wybor.
echo.
echo ZALECANE: Ta opcja skopiuje gre na pulpit a potem ja uruchomi.
echo Zapewni to dobra predkosc zapis/odczyt.
echo.
echo.
echo Uruchom gre z USB
echo =Skopiuj i uruchom gre z komputera=
echo Przenies gre i zapisy z powrotem na USB
echo Pomoc (FAQ)
choice /c:wsk >nul
if %errorlevel%==1 goto opc1
if %errorlevel%==2 goto opc3
if %errorlevel%==3 goto wybropc2
cls

:Opc3
cls
echo CraftRunner by Jakub Pykosz. BETA 7
echo.
echo Korzystasz z dysku %~d0 .
echo.
echo Uzyj kl. W i S aby nawigowac po Menu.
echo Uzyj K aby zatwierdzic wybor. 
echo.
echo Ta opcja przeniesie wszystkie zapisy (swiaty) z powrotem na USB i usunie gre z pulpitu.
echo W zaleznosci o tego, ile jest zapisow, moze to zajac troche czasu.
echo.
echo.
echo Uruchom gre z USB
echo Skopiuj i uruchom gre z komputera
echo =Przenies gre i zapisy z powrotem na USB=
echo Pomoc (FAQ)
choice /c:wsk >nul
if %errorlevel%==1 goto opc2
if %errorlevel%==2 goto opc4
if %errorlevel%==3 goto wybropc3
cls

:Opc4
cls
echo CraftRunner by Jakub Pykosz. BETA 7
echo.
echo Korzystasz z dysku %~d0 .
echo.
echo Uzyj kl. W i S aby nawigowac po Menu.
echo Uzyj K aby zatwierdzic wybor. 
echo.
echo Tu znajdziesz odpowiedzi na swoje pytania
echo i pozbedziesz sie wszelkich watpliwosci.
echo.
echo.
echo Uruchom gre z USB
echo Skopiuj i uruchom gre z komputera
echo Przenies gre i zapisy z powrotem na USB
echo =Pomoc (FAQ)=
choice /c:wsk >nul
if %errorlevel%==1 goto opc3
if %errorlevel%==2 goto opc1
if %errorlevel%==3 goto wybropc4
cls


:wybropc1
cls
echo Uruchamiam gre z danego urzadzenia. 
echo Prosze czekac... Nie zamykaj okna nawet w trakcie dzialania gry.
echo Nie usuwaj urzadzenia USB.
@start "" "%CD%\bin\Minecraft.exe" --workDir "%CD%\data\.minecraft"
goto opc1

:wybropc2
cls
echo Program zacznie dzialanie za 3
timeout /t 1 >nul
cls
echo Program zacznie dzialanie za 2
timeout /t 1 >nul
cls
echo Program zacznie dzialanie za 1
timeout /t 1 >nul
cls
echo Kopiuje gre na pulpit. Poczekaj chwile...
echo To chwile zajmie. Nie usuwaj USB.
timeout /t 1 >nul
mkdir "%USERPROFILE%\desktop\MinecraftPortable"
xcopy %~dp0 %USERPROFILE%\desktop\MinecraftPortable /E /H /C /I /Y /Q
cls
echo Konfiguruje folder z gra na pulpicie...
timeout /t 1 >nul
del %USERPROFILE%\desktop\MinecraftPortable\CraftRunner.bat
xcopy %USERPROFILE%\desktop\MinecraftPortable\config\start.bat %USERPROFILE%\desktop\MinecraftPortable
cls
echo Na pulpicie powinien byc fold. MinecraftPortable.
echo.
echo Uruchamiam gre. Nie zamykaj okna.
echo Gdy przez przypadek zamkniesz gre, uzyj Start.bat w folderze na pulpicie.
timeout /t 1 >nul
color 07
start "" "%USERPROFILE%\desktop\minecraftportable\bin\Minecraft.exe" --workDir "%USERPROFILE%\desktop\minecraftportable\data\.minecraft"
goto opc2

:wybropc3
if exist %USERPROFILE%\desktop\minecraftportable (
	echo Folder istnieje na pulpicie. Za chwile program rozpocznie dzialanie.
cls
echo Program zacznie dzialanie za 3
timeout /t 1 >nul
cls
echo Program zacznie dzialanie za 2
timeout /t 1 >nul
cls
echo Program zacznie dzialanie za 1
timeout /t 1 >nul
cls
echo Aktualizuje zapisy na USB...
echo Nie usuwaj urzadzenia.
echo Moze to grozic utrata danych.
@del %~dp0data\.minecraft\saves /F /Q /S >nul
@rmdir %~dp0data\.minecraft\saves /S /Q >nul
@xcopy %USERPROFILE%\desktop\minecraftportable\data\.minecraft\saves %~dp0data\.minecraft\saves\ /E /H /I /Q >nul
cls
echo Zapisy przeniesione.
timeout /t 1 >nul
echo Usuwam gre z pulpitu...
echo Chwile to zajmie.
timeout /t 1 >nul
@del %USERPROFILE%\desktop\minecraftportable /F /Q /S >nul
@rmdir %USERPROFILE%\desktop\minecraftportable /S /Q >nul
cls
echo przeniesiono zapisy i usunieto z pulpitu!
echo Po nacisnieciu dowolnego klawisza program sie zamknie.
echo Po tym mozesz wyjac USB.
@pause
exit
) else (
	cls
	echo Folder z gra NIE istnieje na pulpicie.
	echo Dla bezpieczenstwa danych na USB, proces zostal przerwany.
	echo Zadne zmiany nie zostaly wprowadzone.
	pause
	exit
)

:wybropc4
cls
echo "------------ POMOC ------------"
echo.
echo Q: Co robi opcja nr. 1?
echo A: Uruchamia gre prosto z pendrive.
echo Nic wtedy nie jest zapisywane na pulpit.
echo.
echo Q: Co robi opcja nr. 2?
echo A: Ta opcja kopiuje gre na pulpit komputera
echo a potem ja uruchamia z pulpitu.
echo.
echo Q: Co robi opcja nr. 3?
echo A: Jezeli gra byla uruchomiona z pulpitu,
echo ta opcja synchronizuje z powrotem twoje
echo swiaty na USB i usuwa gre z pulpitu.
echo Po tym twoje swiaty beda juz bezpieczne na USB.
echo.
echo Q: Za kazdym razem na innym komputerze gra pyta o
echo aktualizacje. Jak to naprawic?
echo A: Na komputerze w domu uruchom gre z USB opcja 1.
echo Launcher zacznie aktualizowac gre, ale potrwa
echo to dlugo, w zaleznosci od urzadzenia USB i internetu.
echo Po tym gra nie powinna pytac o aktualizacje na innych
echo komputerach.
echo.
echo Nacisnij dowolny klawisz by przejsc dalej...
pause >nul
cls
echo "------------ POMOC ------------"
echo.
echo Q: Czy to jest crack?
echo A: Nie, musisz sie zalogowac na swoje konto.
echo.
echo Q: Chce kilku ludziom dac gre na swoje komputery,
echo zeby mogli ze mna grac na np. lekcji.
echo Jak to zrobic?
echo A: Uruchom MineTool z komputera np. kolegi/kolezanki
echo i uzyj opcji 2. Pozwol grze sie skopiowac, wyjmij USB
echo i powtorz na innych komputerach.
echo Miej na uwadze, ze kazdy musi miec konto Microsoft.
echo Po lekcji niech usuna folder z pulpitu.
echo.
echo Q: Przez przypadek usunieto folder z pulpitu.
echo czy moje zapisy sa bezpieczne?
echo A: Na USB nadal beda poprzednie zapisy.
echo.
echo Q: Ile miejsca jest potrzebne?
echo A: 1 - 2 GB to minimum.
echo.
echo Q: Jaki pendrive jest najlepszy?
echo A: Powinno sie korzystac z USB z niebieska
echo wtyczka (usb 3.0/3.1). Port tez powinien byc niebieski
echo aby zapewnic kompatybilnosc.
echo Ja korzystam z 128GB pendrive z usb 3.0.
echo.
echo Nacisnij dowolny klawisz by przejsc dalej...
pause >nul
cls
goto Opc1

