@echo off
echo Uruchamiam gre z pulpitu komputera.
echo Dysk USB nie musi być wlozony.
@start "" "%CD%\bin\Minecraft.exe" --workDir "%CD%\data\.minecraft"
echo Nie zamykaj okna w trakcie gry.
echo.
echo Aby zsynchr. zapis z powrotem na USB, uruchom 
echo CraftRunner i wybierz opcje 3.
echo To rowniez usunie gre z pulpitu, a zapis
echo będzie z powrotem na USB.
echo.
echo Jezeli nie zalezy ci na zapisach,
echo Usun folder z pulpitu.