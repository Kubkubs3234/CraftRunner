@echo off
echo Running from the Desktop..
echo The USB drive is not neccesary.
@start "" "%CD%\bin\Minecraft.exe" --workDir "%CD%\data\.minecraft"
echo Do not close the window.
echo.
echo To sync saves to USB, run CraftRunner 
echo and select the third option.
echo This will remove game from the Desktop
echo and the saves will be secured on your USB.
echo.
echo If you don't care about the saves,
echo just delete the folder from the Desktop.