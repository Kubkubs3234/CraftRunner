@echo off
@cd %~dp0config
type introPL.txt
@cd %~dp0
echo Press anything...
@pause >nul

cls
:Opc1
cls
echo CraftRunner by Jakub Pykosz. BETA 7
echo.
echo You are using the %~d0 drive.
echo.
echo Use W and S to move in the menu.
echo Use K to select.
echo. 
echo This option will run the game straight from the USB.
echo Note that it will be slow.
echo You can use it to update the game, check the Help tab.
echo.
echo =Run from USB=
echo Copy and run from Desktop
echo Move saves back to USB, Delete from desktop
echo Help (FAQ)
choice /c:wsk >nul
if %errorlevel%==1 goto opc4
if %errorlevel%==2 goto opc2
if %errorlevel%==3 goto wybropc1
cls

:Opc2
cls
echo CraftRunner by Jakub Pykosz. BETA 7
echo.
echo You are using the %~d0 drive.
echo.
echo Use W and S to move in the menu.
echo Use K to select.
echo.
echo Recommended: This option will copy the game to your Desktop and run it.
echo This will make the game smoother.
echo.
echo.
echo Run from USB
echo =Copy and run from Desktop=
echo Move saves back to USB, Delete from desktop
echo Help (FAQ)
choice /c:wsk >nul
if %errorlevel%==1 goto opc1
if %errorlevel%==2 goto opc3
if %errorlevel%==3 goto wybropc2
cls

:Opc3
cls
echo CraftRunner by Jakub Pykosz. BETA 7
echo.
echo You are using the %~d0 drive.
echo.
echo Use W and S to move in the menu.
echo Use K to select.
echo.
echo This option will move saves to USB and dispose of the game on the desktop.
echo May take a moment, depending on how many saves are on the USB.
echo.
echo.
echo Run from USB
echo Copy and run from Desktop
echo =Move saves back to USB, Delete from desktop=
echo Help (FAQ)
choice /c:wsk >nul
if %errorlevel%==1 goto opc2
if %errorlevel%==2 goto opc4
if %errorlevel%==3 goto wybropc3
cls

:Opc4
cls
echo CraftRunner by Jakub Pykosz. BETA 7
echo.
echo You are using the %~d0 drive.
echo.
echo Use W and S to move in the menu.
echo Use K to select. 
echo.
echo Here you will find answers to any question
echo regarding Minetool and usage.
echo.
echo.
echo =Run from USB=
echo Copy and run from Desktop
echo Move saves back to USB, Delete from desktop
echo =Help (FAQ)=
choice /c:wsk >nul
if %errorlevel%==1 goto opc3
if %errorlevel%==2 goto opc1
if %errorlevel%==3 goto wybropc4
cls


:wybropc1
cls
echo Running from USB... 
echo Wait... Do not close the window.
echo Do not remove USB.
@start "" "%CD%\bin\Minecraft.exe" --workDir "%CD%\data\.minecraft"
goto opc1

:wybropc2
cls
echo Starting in 3
timeout /t 1 >nul
cls
echo Starting in 2
timeout /t 1 >nul
cls
echo Starting in 1
timeout /t 1 >nul
cls
echo Copying to desktop...
echo This may take a while, do not remove USB.
timeout /t 1 >nul
mkdir "%USERPROFILE%\desktop\MinecraftPortable"
xcopy %~dp0 %USERPROFILE%\desktop\MinecraftPortable /E /H /C /I /Y /Q
cls
echo Configuring the folder on the desktop...
timeout /t 1 >nul
del %USERPROFILE%\desktop\MinecraftPortable\CraftRunner.bat
xcopy %USERPROFILE%\desktop\MinecraftPortable\config\start.bat %USERPROFILE%\desktop\MinecraftPortable
cls
echo There should be a MinecraftPortable folder on the desktop.
echo.
echo Running from Desktop... Do not close the window.
echo If you happen to accidentally close the game, use the Start.bat file
echo in the desktop folder instead of using Minetool on USB.
timeout /t 1 >nul
color 07
start "" "%USERPROFILE%\desktop\minecraftportable\bin\Minecraft.exe" --workDir "%USERPROFILE%\desktop\minecraftportable\data\.minecraft"
goto opc2

:wybropc3
if exist %USERPROFILE%\desktop\minecraftportable (
	echo Folder exists, starting...
cls
echo Starting in 3
timeout /t 1 >nul
cls
echo Starting in 2
timeout /t 1 >nul
cls
echo Starting in 1
timeout /t 1 >nul
cls
echo Updating USB saves...
echo Do not remove USB.
echo This may cause data loss.
@del %~dp0data\.minecraft\saves /F /Q /S >nul
@rmdir %~dp0data\.minecraft\saves /S /Q >nul
@xcopy %USERPROFILE%\desktop\minecraftportable\data\.minecraft\saves %~dp0data\.minecraft\saves\ /E /H /I /Q >nul
cls
echo Saves moved.
timeout /t 1 >nul
echo Removing from Desktop...
echo This may take a while.
timeout /t 1 >nul
@del %USERPROFILE%\desktop\minecraftportable /F /Q /S >nul
@rmdir %USERPROFILE%\desktop\minecraftportable /S /Q >nul
cls
echo Moved saves and deleted from desktop!
echo The program will close.
echo You can remove USB later.
echo.
echo Press anything...
@pause >nul
exit
) else (
	cls
	echo There is no game folder on the Desktop.
	echo The process has been aborted.
	echo No changes were made.
	pause
	exit
)

:wybropc4
cls
echo "------------ POMOC ------------"
echo.
echo Q: What does the 1. option do?
echo A: It runs the game straight from the USB.
echo Nothing is saved on the desktop.
echo.
echo Q: What does the 2. option do?
echo A: This one copies the game to the Desktop
echo then runs it from there.
echo.
echo Q: What does the 3. option do?
echo A: After you have finished playing on desktop,
echo it moves saves from Desktop to USB.
echo The saves will be safe on there.
echo.
echo Q: The game updates taking lots of time. What do i do?
echo A: On your home PC, run game with Option 1.
echo Start the game, it will update it.
echo This may take a moment.
echo After this, the game should not ask anymore.
echo.
echo Press anything...
pause >nul
cls
echo "------------ POMOC ------------"
echo.
echo Q: Is this a crack?
echo A: No, you must log in to your Microsoft.
echo.
echo Q: I want to play with other people in the classroom.
echo How do i do this?
echo A: Run MineTool from your friend's PC and use the second option.
echo Let it do its thing, then remove USB once it did.
echo Repeat on other PCs.
echo Note: Everyone needs a microsoft account.
echo They must delete the game folder later.
echo.
echo Q: I accidentally deleted the game from the Desktop.
echo Are my saves safe?
echo A: There will be your saves since last USB sync.
echo.
echo Q: How much space is needed?
echo A: At least 1 - 2 GB.
echo.
echo Q: What USB drive is the best?
echo A: You should use a 3.0 USB drive.
echo 
echo 

echo.
echo Press anything...
pause >nul
cls
goto Opc1

